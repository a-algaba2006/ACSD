/*
 * ACCESO A DATOS - EXAMEN BLOQUE 1
 * EJERCICIO 1 - 2 puntos
 *
 * ENUNCIADO
 * Copia el contenido del fichero de texto "texto.txt" en un nuevo fichero de
 * texto llamado "texto_backup.txt", y muestra por pantalla cuantos caracteres
 * se han copiado.
 * 
 * REQUISITOS
 *  Los dos ficheros deben quedar cerrados al terminar el programa.
 *
 * EJEMPLO
 *  Si texto.txt contiene:
 *      Hola mundo, esto es una prueba de copia
 *  la salida del programa es:
 *      Hola Mundo, esto es una prueba de copia
        Se han copiado 39 caracteres
 *  y texto_backup.txt queda con el mismo texto que el fichero original.
 *
 * AYUDA
 *   Leer caracteres:              new FileReader(ruta)
 *   Escribir caracteres:          new FileWriter(ruta)
 */

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class Ejercicio1 {

    public static void main(String[] args) {
        
        try {

            FileReader lectura = new FileReader("texto.txt");
            FileWriter escritura = new FileWriter("texto_backup.txt");

            int data;
            int copia = 0;

            while((data = lectura.read()) != -1){
                copia ++;
                escritura.write(data);
                System.out.print((char) data);
            }

            System.out.println("\nSe han copiado: " + copia + " caracteres");

            lectura.close();
            escritura.close();
        
        } catch (IOException ioe) {
            System.out.println("Error de E/S: " + ioe.getMessage());
        } catch(Exception e) {
            System.out.println("Error desconocido: " + e.getMessage());
        }

    }

}