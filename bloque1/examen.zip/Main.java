public class Main {

     public static void main(String[] args) {
        //Escribe el nombre del ejercicio que quieras ejecutar
        Ejercicio1.main(args);
    }
}